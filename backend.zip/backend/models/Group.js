const mongoose = require('mongoose');

// Function to generate a random alphanumeric string
const generateRandomId = () => {
  return Math.random().toString(36).substring(2, 15);
};

const memberSchema = new mongoose.Schema({
  member_id: { type: String, required: true },
  member_name: { type: String, required: true },
  member_contact: { type: String, required: true },
  member_email: { type: String, required: true },
  member_role: { type: String, required: true },
  member_activity_id: { type: String }
});

const groupSchema = new mongoose.Schema({
  group_id: { type: String, default: generateRandomId, unique: true }, // Random alphanumeric ID
  group_name: { type: String, required: true },
  group_members: { type: [memberSchema], required: true }
});

module.exports = mongoose.model('Group', groupSchema);
