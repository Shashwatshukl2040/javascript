const express = require('express');
const router = express.Router();
const controller = require('../controllers/controllers');

router.post('/groups', controller.createGroup);
router.put('/groups/:id', controller.updateGroup);
router.delete('/groups/:id', controller.deleteGroup);
router.get('/groups', controller.getGroups);

router.post('/members', controller.createMember);
router.put('/members/:id', controller.updateMember);
router.delete('/members/:id', controller.deleteMember);
router.get('/members', controller.getMembers);

router.get('/activity-logs', controller.getActivityLogs);

module.exports = router;
