const mongoose = require('mongoose');

// Function to generate a random alphanumeric string
const generateRandomId = () => {
  return Math.random().toString(36).substring(2, 15);
};

const memberSchema = new mongoose.Schema({
  member_id: { type: String, default: generateRandomId, unique: true }, // Random alphanumeric ID
  member_name: { type: String, required: true },
  member_contact: { type: String, required: true },
  member_email: { type: String, required: true },
  member_role: { type: String, required: true },
  member_activity_id: { type: String }
});

module.exports = mongoose.model('Member', memberSchema);
