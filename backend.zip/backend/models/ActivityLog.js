const mongoose = require('mongoose');

// Function to generate a random alphanumeric string
const generateRandomId = () => {
  return Math.random().toString(36).substring(2, 15);
};

const activityLogSchema = new mongoose.Schema({
  member_activity_id: { type: String, default: generateRandomId, unique: true }, // Auto-generated ID
  member_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Member' },
  action: { type: String, enum: ['created', 'deleted'] },
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('ActivityLog', activityLogSchema);
