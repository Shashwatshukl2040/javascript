const Group = require('../models/Group');
const Member = require('../models/Member');
const ActivityLog = require('../models/ActivityLog');
const { v4: uuidv4 } = require('uuid'); // To generate random IDs

// Create a new group
exports.createGroup = async (req, res) => {
  try {
    const group = new Group({
      group_id: uuidv4(), // Generate random ID
      group_name: req.body.group_name,
      group_members: req.body.group_members
    });
    const savedGroup = await group.save();
    res.status(201).json(savedGroup);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update a group
exports.updateGroup = async (req, res) => {
  try {
    const group = await Group.findOne({ group_id: req.params.id });
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }
    group.group_name = req.body.group_name;
    group.group_members = req.body.group_members;
    await group.save();

    // Sync the changes with members
    for (const member of group.group_members) {
      await Member.findOneAndUpdate(
        { member_id: member.member_id },
        { member_name: member.member_name, member_contact: member.member_contact, member_email: member.member_email, member_role: member.member_role }
      );
    }
    res.json(group);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete a group
exports.deleteGroup = async (req, res) => {
  try {
    const group = await Group.findOneAndDelete({ group_id: req.params.id });
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }
    res.json({ message: 'Group deleted' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Create a new member
exports.createMember = async (req, res) => {
  try {
    const member = new Member({
      member_id: uuidv4(), // Generate random ID
      member_name: req.body.member_name,
      member_contact: req.body.member_contact,
      member_email: req.body.member_email,
      member_role: req.body.member_role,
      member_activity_id: uuidv4() // Generate random ID
    });
    const savedMember = await member.save();
    res.status(201).json(savedMember);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Update a member
exports.updateMember = async (req, res) => {
  try {
    const member = await Member.findOne({ member_id: req.params.id });
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }
    member.member_name = req.body.member_name;
    member.member_contact = req.body.member_contact;
    member.member_email = req.body.member_email;
    member.member_role = req.body.member_role;
    await member.save();

    // Sync the changes with groups
    const groups = await Group.find({ 'group_members.member_id': member.member_id });
    for (const group of groups) {
      for (const groupMember of group.group_members) {
        if (groupMember.member_id === member.member_id) {
          groupMember.member_name = member.member_name;
          groupMember.member_contact = member.member_contact;
          groupMember.member_email = member.member_email;
          groupMember.member_role = member.member_role;
        }
      }
      await group.save();
    }
    res.json(member);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Delete a member
exports.deleteMember = async (req, res) => {
  try {
    const member = await Member.findOneAndDelete({ member_id: req.params.id });
    if (!member) {
      return res.status(404).json({ message: 'Member not found' });
    }

    // Delete member from groups
    await Group.updateMany({}, { $pull: { group_members: { member_id: req.params.id } } });

    // Delete member from activity logs
    await ActivityLog.deleteMany({ member_activity_id: member.member_activity_id });

    res.json({ message: 'Member deleted' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// Get all groups
exports.getGroups = async (req, res) => {
  try {
    const groups = await Group.find();
    res.json(groups);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all members
exports.getMembers = async (req, res) => {
  try {
    const members = await Member.find();
    res.json(members);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all activity logs
exports.getActivityLogs = async (req, res) => {
  try {
    const activityLogs = await ActivityLog.find();
    res.json(activityLogs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
